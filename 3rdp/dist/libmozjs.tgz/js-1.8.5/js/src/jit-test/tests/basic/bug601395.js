// |jit-test| error: SyntaxError;
let(y = let(d = []) u, x
