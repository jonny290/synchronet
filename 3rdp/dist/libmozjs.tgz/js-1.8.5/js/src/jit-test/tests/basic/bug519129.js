(function(){eval("for(l in[0,0,0]){}",0)})()
