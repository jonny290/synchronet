// Don't crash.
var re = /^(?:\s*.){0,16}/;
