// |jit-test| error: SyntaxError;
for (let d in [(0)]) let(b = (let(e) {}), d
