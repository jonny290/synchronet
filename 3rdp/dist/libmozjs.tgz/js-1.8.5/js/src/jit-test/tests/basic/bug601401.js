let(e) {
    with({}) try {} catch (x) {} finally {
        let(y) {}
    }
}
