// don't assert
/((?=()+))?/.exec("");

