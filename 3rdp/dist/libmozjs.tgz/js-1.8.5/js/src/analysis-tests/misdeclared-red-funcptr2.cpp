#include "jstypes.h"


// JS_REQUIRES_STACK should come before the *
typedef void (* RedFuncPtr)() JS_REQUIRES_STACK;
